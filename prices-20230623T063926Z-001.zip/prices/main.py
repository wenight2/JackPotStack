import requests
import json
import sys

with open('conf.json', 'r') as source:
    json_data = json.load(source)
urls = json_data['urls']

with open ('product.json', 'r') as p_source:
    product_data = p_source.read()
all_poducts = json.loads(product_data)

#print(all_poducts)

for url in urls:
    for product in all_poducts:
        if product in url:
            name = all_poducts[product]
            response = requests.get(url, timeout=15)
            lowest = '<span class="price" itemprop="lowPrice" content="'
            lines = response.text.splitlines()
            for line in lines:   
                if lowest in line:
                    #print(line)
                    start_marker = ">"
                    end_marker = "<"
                    # Find the index of the start marker
                    start_index = line.find(start_marker)
                    if start_index != -1:
                        # Find the index of the end marker, starting from the index after the start marker
                        end_index = line.find(end_marker, start_index + len(start_marker))
                        if end_index != -1:
                            # Extract the desired substring between the start and end markers
                            extracted_text = line[start_index + len(start_marker):end_index]
                            print(name + ": " + extracted_text)


    
    
    # creating a new file and write in it:
    # file_name = str(f"text_{num}.txt")
    # file = open(file_name, 'w', encoding='utf-8')
    # file.write(response.text)
    # file.close

    # write in an existing file:
    #  with open('raw.txt', 'w', encoding='utf-8') as raw_text:
    #     sys.stdout = raw_text
    #     print(response.text)
    #     sys.stdout = sys.__stdout__


# <span class="price" itemprop="lowPrice" content="
